
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Compass, Swords, Layers, Trophy, 
  Search, Key, LogIn, LogOut, Shield, User, BookOpen 
} from 'lucide-react';
import { UserProfile, UserRank } from '../../types';
import { getRankInfo } from '../../services/rankService';
import { UIState, useUIStore } from '../../src/stores/useUIStore';

interface CommandRailProps {
    userProfile: UserProfile;
    isLoggedIn: boolean;
    onLogoutClick: () => void;
    onToggleCommander: () => void;
    isCommanderOpen: boolean;
}

const RailButton = ({ icon: Icon, label, active, onClick, color = "text-matrix-green", glow = false }: any) => (
    <div className="relative group flex items-center justify-center w-full py-3">
        <button 
            onClick={onClick}
            className={`relative z-10 p-3 rounded-xl transition-all duration-300 ${
                active 
                    ? `bg-white/10 ${color} shadow-[0_0_20px_rgba(255,255,255,0.1)]` 
                    : 'text-gray-500 hover:text-white hover:bg-white/5'
            }`}
        >
            <Icon size={22} className={active && glow ? 'animate-pulse' : ''} />
            {active && (
                <motion.div 
                    layoutId="active-glow"
                    className={`absolute inset-0 rounded-xl border-2 opacity-50 ${active ? 'border-current' : 'border-transparent'}`}
                    transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                />
            )}
        </button>
        
        {/* Tooltip */}
        <div className="absolute left-full ml-4 px-3 py-1.5 bg-black border border-white/10 rounded-lg text-[10px] font-mono font-bold whitespace-nowrap opacity-0 group-hover:opacity-100 translate-x-[-10px] group-hover:translate-x-0 transition-all pointer-events-none z-[60] shadow-2xl">
            <div className="absolute left-0 top-1/2 -translate-x-full -translate-y-1/2 w-0 h-0 border-t-4 border-t-transparent border-b-4 border-b-transparent border-r-4 border-r-white/10"></div>
            {label}
        </div>
    </div>
);

export const CommandRail: React.FC<CommandRailProps> = ({
    userProfile,
    isLoggedIn,
    onLogoutClick,
    onToggleCommander,
    isCommanderOpen
}) => {
    const rank: UserRank = getRankInfo(userProfile.xp);
    const currentView = useUIStore((state: UIState) => state.currentView);
    const setCurrentView = useUIStore((state: UIState) => state.setCurrentView);
    const setShowLogin = useUIStore((state: UIState) => state.setShowLogin);
    const setShowKeyVault = useUIStore((state: UIState) => state.setShowKeyVault);

    return (
        <>
            {/* Desktop Command Rail */}
            <aside className="fixed left-0 top-0 h-screen w-20 z-50 bg-black/40 backdrop-blur-xl border-r border-matrix-green/20 hidden md:flex flex-col items-center py-8">
                
                {/* Top: Primary Navigation */}
                <div className="flex flex-col items-center w-full gap-2 px-2">
                    <RailButton 
                        icon={Compass} 
                        label="DISCOVER_NEXUS" 
                        active={currentView === 'discover'} 
                        onClick={() => setCurrentView('discover')} 
                        color="text-cyan-400"
                    />
                    <RailButton 
                        icon={Swords} 
                        label="ARENA_SKIRMISH" 
                        active={currentView === 'battle'} 
                        onClick={() => setCurrentView('battle')} 
                        color="text-red-500"
                    />
                    <RailButton 
                        icon={Layers} 
                        label="WORKFLOW_ENGINE" 
                        active={currentView === 'workflow'} 
                        onClick={() => setCurrentView('workflow')} 
                        color="text-blue-500"
                    />
                    <RailButton 
                        icon={Trophy} 
                        label="GLOBAL_STANDINGS" 
                        active={currentView === 'rankings'} 
                        onClick={() => setCurrentView('rankings')} 
                        color="text-yellow-500"
                    />
                    <RailButton 
                        icon={BookOpen} 
                        label="DIRECTORY_INDEX" 
                        active={currentView === 'directory'} 
                        onClick={() => setCurrentView('directory')} 
                        color="text-emerald-500"
                    />
                </div>

                {/* Middle: Tactical Search Trigger */}
                <div className="my-auto w-full flex flex-col items-center gap-4">
                    <div className="w-10 h-px bg-white/5" />
                    <RailButton 
                        icon={Search} 
                        label="NEURAL_COMMANDER" 
                        active={isCommanderOpen} 
                        onClick={onToggleCommander} 
                        color="text-matrix-green"
                        glow
                    />
                    <div className="w-10 h-px bg-white/5" />
                </div>

                {/* Bottom: System Controls & Profile */}
                <div className="flex flex-col items-center w-full gap-2 px-2 pb-4">
                    <RailButton 
                        icon={Key} 
                        label="ENCRYPTION_KEYS" 
                        active={false} 
                        onClick={() => setShowKeyVault(true)} 
                        color="text-amber-500"
                    />
                    
                    <div className="mt-4 w-full flex justify-center border-t border-white/5 pt-4">
                        <div className="relative group">
                            <button 
                                onClick={isLoggedIn ? onLogoutClick : () => setShowLogin(true)}
                                className={`w-12 h-12 rounded-xl flex items-center justify-center transition-all duration-500 border overflow-hidden ${
                                    isLoggedIn ? 'border-matrix-green/50 bg-matrix-green/5' : 'border-gray-800 bg-gray-900/50 hover:border-white/30'
                                }`}
                            >
                                {isLoggedIn ? (
                                    <div className="w-full h-full p-1">
                                        <div className="w-full h-full rounded-lg bg-matrix-green flex items-center justify-center text-black font-bold text-xs shadow-[0_0_10px_rgba(0,255,65,0.4)]">
                                            {userProfile.username.substring(0, 1)}
                                        </div>
                                    </div>
                                ) : (
                                    <User size={20} className="text-gray-500 group-hover:text-white" />
                                )}
                            </button>
                            <div className="absolute left-full ml-4 px-3 py-1.5 bg-black border border-white/10 rounded-lg text-[10px] font-mono font-bold whitespace-nowrap opacity-0 group-hover:opacity-100 translate-x-[-10px] group-hover:translate-x-0 transition-all pointer-events-none z-[60]">
                                {isLoggedIn ? `NODE: ${userProfile.username} (DISCONNECT)` : "LINK_NEURAL_IDENTITY"}
                            </div>
                        </div>
                    </div>
                </div>
            </aside>

            {/* Mobile Bottom Bar */}
            <nav className="fixed bottom-0 left-0 right-0 h-16 bg-black/80 backdrop-blur-xl border-t border-white/10 z-[100] md:hidden flex items-center justify-around px-4">
                <button onClick={() => setCurrentView('discover')} className={`p-3 ${currentView === 'discover' ? 'text-matrix-green' : 'text-gray-500'}`}><Compass size={24} /></button>
                <button onClick={() => setCurrentView('battle')} className={`p-3 ${currentView === 'battle' ? 'text-red-500' : 'text-gray-500'}`}><Swords size={24} /></button>
                <button onClick={onToggleCommander} className={`p-3 ${isCommanderOpen ? 'text-matrix-green animate-pulse' : 'text-gray-500'}`}><Search size={24} /></button>
                <button onClick={() => setCurrentView('workflow')} className={`p-3 ${currentView === 'workflow' ? 'text-blue-500' : 'text-gray-500'}`}><Layers size={24} /></button>
                <button onClick={isLoggedIn ? onLogoutClick : () => setShowLogin(true)} className={`p-3 ${isLoggedIn ? 'text-matrix-green' : 'text-gray-500'}`}>{isLoggedIn ? <Shield size={24} /> : <LogIn size={24} />}</button>
            </nav>
        </>
    );
};
